$(document).ready(function(){
    $('.burger').click(function()
    {
        $('.burger').toggleClass('burger-show')        
        $('.nav-items').toggleClass('menu-show')
    })
})